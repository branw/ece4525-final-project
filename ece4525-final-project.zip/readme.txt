Milestone #1 

Current version of the game has the WarioWare main screen with two Warios dancing.

There are three buttons. The buttons will bounce when hovered over.

Our names (Lucas | Brandon) are present at the bottom of the border in the intro screen.

Option screen contains a place holder that will later become options to change the difficulty of the game.

The help screen contains brief instructions on how to play the game and which peripherals to use in order to interact with the game.

The start button will start the transition that fades in into black screen and fades out back to the transition screen (boom box).

When the transition finishes, a place holder for the minigame (green screen with most of the sprites that will be used in the minigames) will appear.

