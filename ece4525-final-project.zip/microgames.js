class Microgame {

}
